<?php
/*
Plugin Name: simplemp3player
Plugin URI: http://www.programvarekontoret.no/wp1
Description: Upload your MP3 files and insert into post without any fuzz.
Author: http://www.programvarekontoret.no
Version: 1.1
Author URI: http://www.programvarekontoret.no
*/


add_shortcode('mp3post', 'shortcode');
add_action('wp_print_scripts', 'addPlayerScripts');
add_action('wp_head', 'addPlayerJavascript');
add_filter('media_send_to_editor', 'media_send', 10 , 3 );
add_action( 'media_buttons', 'media_button_MP3', 1000 );
add_filter('media_upload_mp3', 'media_upload_mp3');

global $ismp3;

function media_upload_mp3() {
	global $ismp3;
	$ismp3 = true;
	$errors = array();
	$id = 0;

	if ( isset($_POST['html-upload']) && !empty($_FILES) ) {
		// Upload File button was clicked
		$id = media_handle_upload('async-upload', $_REQUEST['post_id']);
		unset($_FILES);
		if ( is_wp_error($id) ) {
			$errors['upload_error'] = $id;
			$id = false;
		}
	}

	if ( !empty($_POST['insertonlybutton']) ) {
		$href = $_POST['insertonly']['href'];
		if ( !empty($href) && !strpos($href, '://') )
			$href = "http://$href";
		$title = attribute_escape($_POST['insertonly']['title']);
		if ( empty($title) )
			$title = basename($href);
		if ( !empty($title) && !empty($href) )
			$html = "<a href='$href' >$title</a>";
		return media_send_to_editor($html);
	}

	if ( !empty($_POST) ) {
		$return = media_upload_form_handler();

		if ( is_string($return) )
			return $return;
		if ( is_array($return) )
			$errors = $return;
	}

	if ( isset($_POST['save']) ) {
		$errors['upload_notice'] = __('Saved.');
		return media_upload_gallery();
	}

	if ( isset($_GET['tab']) && $_GET['tab'] == 'type_url' )
		return wp_iframe( 'media_upload_type_url_form', 'mp3', $errors, $id );

	return wp_iframe( 'media_upload_type_form', 'mp3', $errors, $id );
}

function type_url_form_mp3() {
	return '
	<table class="describe"><tbody>
		<tr>
			<th valign="top" scope="row" class="label">
				<span class="alignleft"><label for="insertonly[href]">' . __('MP3 File URL') . '</label></span>
				<span class="alignright"><abbr title="required" class="required">*</abbr></span>
			</th>
			<td class="field"><input id="insertonly[href]" name="insertonly[href]" value="" type="text" aria-required="true"></td>
		</tr>
		<tr>
			<th valign="top" scope="row" class="label">
				<span class="alignleft"><label for="insertonly[title]">' . __('Title') . '</label></span>
				<span class="alignright"><abbr title="required" class="required">*</abbr></span>
			</th>
			<td class="field"><input id="insertonly[title]" name="insertonly[title]" value="" type="text" aria-required="true"></td>
		</tr>
		<tr><td></td><td class="help">' . __('Link text, e.g. "Still Alive by Jonathan Coulton"') . '</td></tr>
		<tr>
			<td></td>
			<td>
				<input type="submit" class="button" name="insertonlybutton" value="' . attribute_escape(__('Insert into Post')) . '" />
			</td>
		</tr>
	</tbody></table>
';
}

function media_button_MP3() {
	global $post_ID, $temp_ID;
	$uploading_iframe_ID = (int) (0 == $post_ID ? $temp_ID : $post_ID);
	$context = apply_filters('media_buttons_context', __('%s'));
	$mp3_upload_iframe_src = "media-upload.php?type=mp3&post_id=$uploading_iframe_ID";
	$mp3_title = __('Add MP3');
	$out = <<<EOF

	<a href="{$mp3_upload_iframe_src}&amp;TB_iframe=true" id="add_mp3" class="thickbox" title='$mp3_title'><img src='../wp-content/plugins/mp3post/mp3_button_1.gif' alt='$mp3_title' /></a>

EOF;
	printf($context, $out);
}

function media_send($html, $attachment_id, $attachment) {
	$post =& get_post($attachment_id);
	$posttype = $post->post_mime_type;
	if ($posttype == 'audio/mpeg' ) {
		return "[mp3post]" . $post->guid . "[/mp3post]";
	} else {
		return $html;
	}
}

function addPlayerScripts() {
	wp_enqueue_script('swfobject', plugins_url('/mp3post/player/swfobject.js'), false, '2.1');
	wp_enqueue_script('audio-player', plugins_url('/mp3post/player/mp3post.js'), false, '2.0');
}

function addPlayerJavascript() {
	$global_flashvars = stripslashes(get_option('pod_player_flashvars'));
	
	if ( get_option('pod_player_flashvars') != '' )
		$global_flashvars = ', ' . $global_flashvars;
	
	$pod_player_width = stripslashes(get_option('pod_audio_width'));
	if ( $pod_player_width == '' )
		$pod_player_width = 290;
	
	?>
	<script type="text/javascript">
		thePlayer.setup("<?php echo plugins_url('/mp3post/player/mp3post.swf'); ?>", {  
			width: <?php echo $pod_player_width . $global_flashvars; ?>
		});
	</script>
	<?php
}
	
function shortcode( $atts, $content = null ) {
	global $post, $podcasting_excerpt_check;
	
	if ( $podcasting_excerpt_check )
		return '';
	
	extract( shortcode_atts( array(
		'format' => 'mp3',
		'width' => get_option('pod_player_width'),
		'height' => get_option('pod_player_height'),
		'flashvars' => ''
		), $atts ) );
	
	return audioPlayer($content, $width, $height, $flashvars);
}

function audioPlayer($content, $width, $height, $flashvars)
{
	global $post ;
	$fullpath = $content;
	$podcasting_player_url = plugins_url('/mp3post/player/mp3post.swf');

	if ( $flashvars != '' )
		$flashvars = ', ' . $flashvars;

	return '<span id="pod_audio_' . $post->ID . '">&nbsp;</span>
	<script type="text/javascript">  
		thePlayer.embed("pod_audio_' . $post->ID . '", {soundFile: "' . rawurlencode($fullpath) . '"' . $flashvars . '});  
	</script>
	';
}

?>
