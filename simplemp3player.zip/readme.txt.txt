=== Plugin Name ===
Contributors: Programvarekontoret
Donate link: http://www.programvarekontoret.no/wp1
Tags: Simple MP3 Player
Requires at least: 2.7
Tested up to: 2.7
Stable tag: 1.1

A simple MP3 player that enables you to upload directly from your local computer and insert into post.

== Description ==

A simple MP3 player that enables you to upload directly from your local computer and insert into post
by a add-on button in the "Add New Post" section. Free for personal use, USD $29.95 for professional use payable to faktura@programvarekontoret.no via PayPal. Contact webmaster@programvarekontoret.no if you have any questions.

== Installation ==

Simple installation:.

1. Upload `Simple MP3 foleder to the '/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Find the button on the menu in "Add New Post" and click once - and insert.

== Frequently Asked Questions ==

Q: Is it free?
A: Yes, for personal use the pluging is free. For professional use the plugin cost $29.95 payable to faktura@programvarekontoret.no via PayPal. Contact webmaster@programvarekontoret.no if you have any questions.

Q: What if I'm not satisfied?
A: Then its your loss. No returns.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

http://www.programvarekontoret.no/wp1/

== Arbitrary section ==

None

== A brief Markdown Example ==

None

